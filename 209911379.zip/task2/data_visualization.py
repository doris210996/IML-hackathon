import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.ndimage.filters import gaussian_filter
import matplotlib.cm as cm
import matplotlib.animation as animation
import math

from scipy.stats import gaussian_kde
from plotly.subplots import make_subplots
# Imports and settings for plotting of graphs
# import plotly.io as pio
import plotly.graph_objects as go
import plotly.express as px
import seaborn as sns
import datetime
from sklearn.cluster import KMeans


crimes = [
    'BATTERY',
    'THEFT' ,
    'CRIMINAL DAMAGE',
    'DECEPTIVE PRACTICE',
    'ASSAULT' ,
]

def data_vis(data):

    plt.scatter(data["X Coordinate"], data["Y Coordinate"], c=data["District"], cmap='viridis')
    plt.show()
    plt.scatter(data["X Coordinate"], data["Y Coordinate"], c=data["Beat"], cmap='viridis')
    plt.show()
    # heat_map(data, "X Coordinate", "Y Coordinate")


    return

def histo(data, feature):

    x1 = list(data[data['Primary Type'] == crimes[0]][feature])
    x2 = list(data[data['Primary Type'] == crimes[1]][feature])
    x3 = list(data[data['Primary Type'] == crimes[2]][feature])
    x4 = list(data[data['Primary Type'] == crimes[3]][feature])
    x5 = list(data[data['Primary Type'] == crimes[4]][feature])

    # Assign colors for each airline and the names
    colors = ['#E69F00', '#56B4E9', '#F0E442', '#009E73', '#D55E00']
    names = crimes

    # Make the histogram using a list of lists
    # Normalize the flights and assign colors and names
    plt.hist([x1, x2, x3, x4, x5], bins = int(180/15), color = colors, label=names)

    # Plot formatting
    plt.legend()
    plt.xlabel(feature)
    plt.ylabel("count")
    plt.title(f'side by side crimes by {feature}')
    plt.show()

def density_crimes(data, feature):


    # Iterate through the five airlines
    for crime in crimes:
        # Subset to the airline
        subset = data[data['Primary Type'] == crime]
        # Draw the density plot
        sns.kdeplot(subset[feature],label = crime, shade=True)

    # Plot formatting
    plt.legend(prop={'size': 10}, title = 'crimes')
    plt.title('Density Plot with Multiple crimes')
    plt.xlabel(feature)
    plt.ylabel('Density')
    plt.show()

def density_fit(data, feature, fit):


    # Iterate through the five airlines
    for f in data[fit].unique():
        # Subset to the airline
        subset = data[data[fit] == f]
        # Draw the density plot
        sns.kdeplot(subset[feature],label = f, shade=True)

    # Plot formatting
    plt.legend(prop={'size': 10}, title = fit)
    plt.title('Density Plot with Multiple fit')
    plt.xlabel(feature)
    plt.ylabel('Density')
    plt.show()



def heat_map(data, x, y):
    def myplot(x, y, s, bins=1000):
        heatmap, xedges, yedges = np.histogram2d(x, y, 1000)
        heatmap = gaussian_filter(heatmap, sigma=s)


        extent = [xedges[0], xedges[-1], yedges[0], yedges[-1]]
        return heatmap.T, extent



    sigmas = [16, 64]

    for s in sigmas:
        for crime in crimes:
            fig, axs = plt.subplots(1, 1)
            img, extent = myplot(data[data["Primary Type"] == crime][x], data[data["Primary Type"] == crime][y], s)
            axs.imshow(img, extent=extent, origin='lower', cmap=cm.jet)
            axs.set_title(f"Smoothing with  $\sigma$ = {s} for {crime}")
            plt.show()