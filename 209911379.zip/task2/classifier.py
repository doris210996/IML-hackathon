import pickle
import pandas as pd
import train
import prep
import car_send
from train import CrimeClassifier,train
from car_send import SendCopClassifier
from collections import Counter
from sklearn.cluster import KMeans
import numpy as np
from prep import *
from sklearn.ensemble import StackingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
import pickle
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from imblearn.under_sampling import EditedNearestNeighbours, RepeatedEditedNearestNeighbours
from sklearn.model_selection import train_test_split, RepeatedStratifiedKFold, cross_val_score
import holidays
from collections import Counter
from sklearn.neural_network import MLPClassifier
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
import pickle
pd.options.mode.chained_assignment = None
from sklearn.decomposition import PCA
from sklearn.neighbors import RadiusNeighborsClassifier
import pandas as pd
from sklearn import preprocessing
from scipy.stats import gaussian_kde
from sklearn import preprocessing
import holidays
from collections import Counter
from sklearn.preprocessing import OrdinalEncoder

IRRELEVANT_FEATURES = ['Unnamed: 0', 'ID', 'Case Number', 'Block', 'IUCR', 'Description', 'FBI Code',
                       'X Coordinate', 'Y Coordinate', 'Updated On', 'Location', 'Beat', 'Ward', 'Community Area']

dict_crimes = {
    0: 'BATTERY',
    1: 'THEFT',
    2: 'CRIMINAL DAMAGE',
    3: 'DECEPTIVE PRACTICE',
    4: 'ASSAULT',
}

crimes = [
    'BATTERY',
    'THEFT' ,
    'CRIMINAL DAMAGE',
    'DECEPTIVE PRACTICE',
    'ASSAULT' ,
]

from sklearn.model_selection import train_test_split


def divide_data(data):
    """
    divides the data to train, test, validation sets where 80% train,
    10% test, 10% validation

    :return: none
    """
    X_train, X_test= train_test_split(data, test_size=0.2)

    X_test, X_valid = train_test_split(X_test, test_size=0.5)
    return X_train, X_test,X_valid
    # train.to_csv('train.csv', index=False)
    # test.to_csv('test.csv', index=False)
    # validation.to_csv('validation.csv', index=False)


def load_data():
    file1 = "dataset_crimes.csv"
    data = pd.read_csv(file1)
    return data


# for baseline
def sample_filter_basic(data):
    data.drop(['ID', 'Case Number', 'Year', 'Unnamed: 0', "FBI Code", "IUCR", "Description", "Latitude", "Longitude",
               "Location", "Ward", "Community Area", "Beat"], axis=1, inplace=True)
    data.dropna(inplace=True, axis=0)
    data.drop_duplicates(inplace=True)

    data = data[((data['Arrest'] == True) | (data['Arrest'] == False))
                & ((data['Domestic'] == True) | (data['Domestic'] == False))]
    return data


def convert_to_num(df):
    df["Arrest"] = df["Arrest"].astype(int)
    df["Domestic"] = df["Domestic"].astype(int)
    return df


def date_time(df):
    df['Date'] = pd.to_datetime(df['Date']).astype(np.int64)
    df['Hour'] = df['Date'].dt.hour.astype(np.int64)
    df['Month'] = df['Date'].dt.month.astype(np.int64)
    df['Day_of_week'] = df['Date'].dt.dayofweek.astype(np.int64)
    df['Updated On'] = pd.to_datetime(df['Updated On']).astype(np.int64)
    df['Report_Update_Diff'] = (df['Updated On'] - df['Date']).dt.days.astype(np.int64)

    # drop original vars
    df.drop(['Date', 'Updated On'], axis=1, inplace=True)
    return df


def location_des(data):
    regex_dict = {
        "TRANSPORT": r'(TRANSPORT|\bBUS\b|\bCTA)',
        "PRIV_TRANS": r'(VEHICLE\b|\bPARKING\b|\bHIGHWAY)',
        "AIR": r'(AIRPORT\b|\bAIRCRAFT)',
        "PUBLIC" : r'(\bSTORE\b|\bSHOP\b|\bRESTAURANT\b|\bOFFICE\b|\bBANK\b|\bATM\b|\bCURRENCY\bTRANSPORT'
                   r'|\bBUS\b|\bCTA\b|\bAIRCRAFT\b|BUILDING\b\|bSCHOOL\b|\bCOLLEGE\b|\bOFFICE)',
        "PRIVATE" : r'(APARTMENT)',
        "SCHOOL" : r'(SCHOOL\b|\bCOLLEGE\b)',
        "MONEY":r'(BANK\b|\bATM\b|\bCURRENCY\b)',
        "SHOP": r'(\bSTORE\b|\bSHOP\b|\bRESTAURANT)',
        "RESIDENCE": r'(RESIDENCE)',
    }
    for key, value in regex_dict.items():
        data[key] = data['Location Description'].str.extract(value)
        data[key] = data[key].fillna(0)
        data.loc[data[key]!=0, key] = 1
    data.drop(['Location Description'], axis=1, inplace=True)
    return data


def prep(X):
    X = X.drop(IRRELEVANT_FEATURES, axis=1)
    X = X.dropna()

    #
    X.insert(8, "Day", X['Date'].str.split('/', 2, expand=True)[1])
    X.loc[:, 'Day'] = pd.to_numeric(X.loc[:, 'Day'])
    X.insert(9, "Month", X['Date'].str.split('/', 1, expand=True)[0])
    X.loc[:, 'Month'] = pd.to_numeric(X.loc[:, 'Month'])
    tmp_min = X['Date'].str.split(':', 2, expand=True)
    X.insert(8, "Min", tmp_min[1])

    tmp = X['Date'].str.split(' ', 2, expand=True)
    tmp.insert(0, "Hour", pd.to_numeric(tmp[1].str.split(':', 1, expand=True)[0]))
    tmp.loc[tmp[2] == "PM", 'Hour'] += 12
    tmp.loc[tmp['Hour'] == 24, 'Hour'] = 0
    X.insert(8, "Hour", tmp['Hour'])
    X.drop(['Date', 'Year'], axis=1)
    X['Arrest'] = X['Arrest'].astype(int)
    X['Domestic'] = X['Domestic'].astype(int)

    #
    enc = OrdinalEncoder()
    X['Location Description'] = enc.fit_transform(X[['Location Description']])
    X.drop(['Date', 'Year'], axis=1, inplace=True)

    X.reset_index(drop=True, inplace=True)

    return X

crimes_dict = {0: 'BATTERY', 1: 'THEFT', 2: 'CRIMINAL DAMAGE', 3: 'DECEPTIVE PRACTICE', 4: 'ASSAULT'}



class CrimeClassifier(object):
    def __init__(self):
        self.centers = None
        level0 = list()
        level0.append(('rf', RandomForestClassifier(min_samples_split=60)))
        level0.append(('ada', AdaBoostClassifier(base_estimator=DecisionTreeClassifier(max_depth=2), n_estimators=110)))
        level0.append(('grdBoost', GradientBoostingClassifier(max_depth=3)))  # logiscic regression
        self.model = StackingClassifier(estimators=level0, final_estimator=LogisticRegression(max_iter=300), cv=5)
        self.centers = []
        self.crime_centers = {
            'BATTERY': [],
            'THEFT': [],
            'CRIMINAL DAMAGE': [],
            'DECEPTIVE PRACTICE': [],
            'ASSAULT': [],
        }
        self.crime_blocks = {
            'BATTERY': [],
            'THEFT': [],
            'CRIMINAL DAMAGE': [],
            'DECEPTIVE PRACTICE': [],
            'ASSAULT': [],
        }


    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):

        return self.model.predict(X)

    def score(self, X, y):
        return self.model.score(X, y)

    def sample_process(self,data):
        data = prep(data)
        return data

    def dist_from_danger(self,data):
        points = data[["X Coordinate", "Y Coordinate"]]
        dist = lambda point: np.sqrt((points["X Coordinate"] - point[0]).pow(2) + (points["Y Coordinate"] - point[1]).pow(2))
        for crime in self.crime_blocks.keys():
            data[f"{crime} center1"] =dist(self.crime_centers[crime][0])
            data[f"{crime} center1"] = dist(self.crime_centers[crime][1])
            data[f"{crime} center1"] =dist(self.crime_centers[crime][2])
        return data

    def block_feature(self, data):
        for crime in self.crime_blocks.keys():
            feature_name = crime + " most common"
            data[feature_name] = data["Block"].isin(self.crime_blocks[crime][:15])
            data[f"{feature_name} NON"] = data["Block"].isin(self.crime_blocks[crime][:-50:-1])
        data.drop(["Block"], axis=1, inplace=True)
        return data

    def preprocess_special(self, data):
        data = district(data)
        # data = self.dist_from_danger(data)
        # data = self.block_feature(data)
        return data



def convert_response(res):
    return pd.DataFrame(res).applymap(lambda s: dict((v, k) for k, v in dict_crimes.items()).get(s))


def response(X):
    res = np.ravel(convert_response(X["Primary Type"]))
    X = X.drop(["Primary Type"], axis=1)
    return X, res


def info_means(data, my_model):
    for crime in crimes:
        points = data[data["Primary Type"] == crime][["X Coordinate", "Y Coordinate"]]
        kmeans = KMeans(n_clusters=3, random_state=0).fit(points)
        my_model.crime_centers[crime] = kmeans.cluster_centers_

    # points = data[["X Coordinate", "Y Coordinate"]]
    # kmeans = KMeans(n_clusters=3, random_state=0).fit(points)
    # my_model.centers = kmeans.cluster_centers_


def info_blocks(data, my_model):
    for crime in my_model.crime_blocks.keys():
        lst = data[data["Primary Type"] == crime]['Block']
        counts = Counter(lst)
        my_model.crime_blocks[crime] = sorted(lst.unique(), key=lambda x: -counts[x])[:7]

def district(df):
    for i in range(1,31):
        df['District'+str(i)] = 0
        df.loc[df['District'] == i, 'District'+str(i)] = 1
    df.drop(["District"], axis =1, inplace =True)
    return df


def add_half_hours(df):
    df['Half_hours'] = df['Hour'] * 2
    df.loc[df['Date'].dt.minute > 30, 'Half_hours'] = df['Half_hours'] + 1


def train(X_train, my_model):
    X_train = my_model.sample_process(X_train)
    X_train, y = response(X_train)
    my_model.fit(X_train, y)



class SendCopClassifier(object):
    def __init__(self):
        self.day_of_week = []

    def fit(self, X):
        for i in range(7):
            self.model = KMeans(n_clusters=30, random_state=0).fit(X[X["Day_of_week"] == i].drop(["Day_of_week"], axis = 1))
            self.day_of_week.append(self.model.cluster_centers_)


    def send_police_cars(self, X):
        date = pd.to_datetime(X)
        table = self.day_of_week[date.dayofweek]

        table[:,0] = np.round(table[:,0])
        table[:,1] = np.round(table[:,1])
        table2 = pd.DataFrame(table[:,0:2], columns =["x", "y"])
        table2['time'] = date + pd.to_timedelta(np.round(table[:,2]*30), unit='m')

        return list(table2.itertuples(index=False, name=None))


def date_time(df):
    df['Date'] = pd.to_datetime(df['Date'])
    df['Day_of_week'] = df['Date'].dt.dayofweek.astype(np.int64)
    df['Hour'] = df['Date'].dt.hour.astype(np.int64)
    df['Half_hours'] = df['Hour']*2
    df.loc[df['Date'].dt.minute > 30, 'Half_hours'] = df['Half_hours'] + 1
    return df


def sample_filter_basic_cars(data):
    data.dropna(inplace=True, axis=0)
    data.drop_duplicates(inplace=True)
    return data

def send_cars_prep(df):
    df = sample_filter_basic_cars(df)
    df = date_time(df)
    df = df[["X Coordinate", "Y Coordinate", "Day_of_week", "Half_hours"]]
    return df

def train_police_car():
    X = load_data().reset_index()
    X1 = send_cars_prep(X)
    cls = SendCopClassifier()
    cls.fit(X1)
    return cls

def predict(X):
    mod = CrimeClassifier()
    X = pd.read_csv(X)
    X = mod.sample_process(X)
    X_train = load_data()
    train(X_train,mod)
    return mod.predict(X)


def send_police_cars(X):
    print(X)
    X = send_cars_prep(X)
    model = train_police_car()
    return model.send_police_cars(X)






