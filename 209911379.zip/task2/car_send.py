
from sklearn.cluster import KMeans
import pandas as pd
import numpy as np
import pickle
from prep import load_data

class SendCopClassifier(object):
    def __init__(self):
        self.day_of_week = []

    def fit(self, X):
        for i in range(7):
            self.model = KMeans(n_clusters=30, random_state=0).fit(X[X["Day_of_week"] == i].drop(["Day_of_week"], axis = 1))
            self.day_of_week.append(self.model.cluster_centers_)


    def send_police_cars(self, X):
        date = pd.to_datetime(X)
        table = self.day_of_week[date.dayofweek]

        table[:,0] = np.round(table[:,0])
        table[:,1] = np.round(table[:,1])
        table2 = pd.DataFrame(table[:,0:2], columns =["x", "y"])
        table2['time'] = date + pd.to_timedelta(np.round(table[:,2]*30), unit='m')

        return list(table2.itertuples(index=False, name=None))


def date_time(df):
    df['Date'] = pd.to_datetime(df['Date'])
    df['Day_of_week'] = df['Date'].dt.dayofweek.astype(np.int64)
    df['Hour'] = df['Date'].dt.hour.astype(np.int64)
    df['Half_hours'] = df['Hour']*2
    df.loc[df['Date'].dt.minute > 30, 'Half_hours'] = df['Half_hours'] + 1
    return df



def sample_filter_basic_cars(data):
    data.dropna(inplace=True, axis=0)
    data.drop_duplicates(inplace=True)
    return data

def send_cars_prep(df):
    df = sample_filter_basic_cars(df)
    df = date_time(df)
    df = df[["X Coordinate", "Y Coordinate", "Day_of_week", "Half_hours"]]
    return df

def train_police_car():
    X = load_data().reset_index()
    X1 = send_cars_prep(X)
    cls = SendCopClassifier()
    cls.fit(X1)
    return cls

def p():
    mod = train_police_car()
    with open("myModel_car.pkl", "wb") as output:
        pickle.dump(mod, output, protocol=4)


# p()