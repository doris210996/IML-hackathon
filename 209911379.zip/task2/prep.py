
import numpy as np
import pandas as pd
from sklearn import preprocessing
from scipy.stats import gaussian_kde
from sklearn import preprocessing
import holidays
from collections import Counter

dict_crimes = {
    0: 'BATTERY',
    1: 'THEFT',
    2: 'CRIMINAL DAMAGE',
    3: 'DECEPTIVE PRACTICE',
    4: 'ASSAULT',
}

crimes = [
    'BATTERY',
    'THEFT' ,
    'CRIMINAL DAMAGE',
    'DECEPTIVE PRACTICE',
    'ASSAULT' ,
]

from sklearn.model_selection import train_test_split


def divide_data(data):
    """
    divides the data to train, test, validation sets where 80% train,
    10% test, 10% validation

    :return: none
    """
    X_train, X_test= train_test_split(data, test_size=0.2)

    X_test, X_valid = train_test_split(X_test, test_size=0.5)
    return X_train, X_test,X_valid
    # train.to_csv('train.csv', index=False)
    # test.to_csv('test.csv', index=False)
    # validation.to_csv('validation.csv', index=False)


def load_data():
    file1 = "Dataset_crimes.csv"
    file2 = "crimes_dataset_part2.csv"

    df1 = pd.read_csv(file1)
    df2 = pd.read_csv(file2)
    data = pd.concat([df1, df2], axis=0)
    return data


# for baseline
def sample_filter_basic(data):
    data.drop(['ID', 'Case Number', 'Year', 'Unnamed: 0', "FBI Code", "IUCR", "Description", "Latitude", "Longitude",
               "Location", "Ward", "Community Area", "Beat"], axis=1, inplace=True)
    data.dropna(inplace=True, axis=0)
    data.drop_duplicates(inplace=True)

    data = data[((data['Arrest'] == True) | (data['Arrest'] == False))
                & ((data['Domestic'] == True) | (data['Domestic'] == False))]
    return data


def convert_to_num(df):
    df["Arrest"] = df["Arrest"].astype(int)
    df["Domestic"] = df["Domestic"].astype(int)
    return df


def date_time(df):
    df['Date'] = pd.to_datetime(df['Date'])
    df['Hour'] = df['Date'].dt.hour.astype(np.int64)
    df['Month'] = df['Date'].dt.month.astype(np.int64)
    df['Day_of_week'] = df['Date'].dt.dayofweek.astype(np.int64)
    df['Updated On'] = pd.to_datetime(df['Updated On'])
    df['Report_Update_Diff'] = (df['Updated On'] - df['Date']).dt.days.astype(np.int64)

    # drop original vars
    df.drop(['Date', 'Updated On'], axis=1, inplace=True)
    return df


def location_des(data):
    regex_dict = {
        "TRANSPORT": r'(TRANSPORT|\bBUS\b|\bCTA)',
        "PRIV_TRANS": r'(VEHICLE\b|\bPARKING\b|\bHIGHWAY)',
        "AIR": r'(AIRPORT\b|\bAIRCRAFT)',
        "PUBLIC" : r'(\bSTORE\b|\bSHOP\b|\bRESTAURANT\b|\bOFFICE\b|\bBANK\b|\bATM\b|\bCURRENCY\bTRANSPORT'
                   r'|\bBUS\b|\bCTA\b|\bAIRCRAFT\b|BUILDING\b\|bSCHOOL\b|\bCOLLEGE\b|\bOFFICE)',
        "PRIVATE" : r'(APARTMENT)',
        "SCHOOL" : r'(SCHOOL\b|\bCOLLEGE\b)',
        "MONEY":r'(BANK\b|\bATM\b|\bCURRENCY\b)',
        "SHOP": r'(\bSTORE\b|\bSHOP\b|\bRESTAURANT)',
        "RESIDENCE": r'(RESIDENCE)',
    }
    for key, value in regex_dict.items():
        data[key] = data['Location Description'].str.extract(value)
        data[key] = data[key].fillna(0)
        data.loc[data[key]!=0, key] = 1
    data.drop(['Location Description'], axis=1, inplace=True)
    return data


def prep(data):
    data = sample_filter_basic(data)
    data = date_time(data)
    data = location_des(data)
    data = convert_to_num(data)
    return data


