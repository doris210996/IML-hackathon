
USERS.txt - As required
project.pdf - As required
README.txt - This file

/task2
classifier.py - As required
prep.py - contitains all functions deal with dividing ad preproccesing the data
train.py - contains the the functions we used to create our model
car_send.py - contains the the functions we used to create our model
data_visualization.py - Contains all functions we used to the declared purpose
requirments.txt - As required
myModel.pkl - pickle of task 1 atributes
myModel_car.pkl - pickle of task 2 atributes

